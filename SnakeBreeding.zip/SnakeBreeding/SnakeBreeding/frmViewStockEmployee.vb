﻿Public Class frmViewStockEmployee
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim Employee As New frmEmployee
        Employee.Show()
        Me.Hide()
    End Sub
End Class