﻿Public Class frmViewSpecimenOwner
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim Owner As New frmOwner
        Owner.Show()
        Me.Hide()
    End Sub

    Private Sub btnMF_Click(sender As Object, e As EventArgs) Handles btnMF.Click
        Dim Schedule As New frmScheduleOwner
        Schedule.Show()
        Me.Hide()
    End Sub

    Private Sub btnExport_Click(sender As Object, e As EventArgs) Handles btnExport.Click

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        'Dim specimenNumber As String
        ' Dim species As String
        'Dim hatchDate As String
        'Dim sex As String
        'Dim weight As String
        'Dim colorMorph As String
        'Dim nextBreedDate As String

        'specimenNumber = txtSpecimen.Text.ToString
        ' species = txtSpecies.Text.ToString
        'hatchDate = txtHatchDate.Text.ToString
        'sex = txtSex.Text.ToString
        'weight = txtWeight.Text.ToString
        'colorMorph = txtColorMorph.Text.ToString
        'nextBreedDate = txtNextBreedDate.Text.ToString

        txtSpecimen.Text = "test"
        txtSpecies.Text = "Python"
        txtHatchDate.Text = "November 15th"
        txtSex.Text = "Male"
        txtWeight.Text = "69 Pounds"
        txtColorMorph.Text = "Yellow"
        txtNextBreedDate.Text = " January 12"
    End Sub
End Class