﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmViewSpecimenEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmViewSpecimenEmployee))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtSpecimen = New System.Windows.Forms.TextBox()
        Me.txtSpecies = New System.Windows.Forms.TextBox()
        Me.txtHatchDate = New System.Windows.Forms.TextBox()
        Me.txtSex = New System.Windows.Forms.TextBox()
        Me.txtWeight = New System.Windows.Forms.TextBox()
        Me.txtColorMorph = New System.Windows.Forms.TextBox()
        Me.txtNextBreedDate = New System.Windows.Forms.TextBox()
        Me.btnBreedingPrediction = New System.Windows.Forms.Button()
        Me.btnMF = New System.Windows.Forms.Button()
        Me.btnExport = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(49, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Specimen #:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(68, 51)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Species:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(51, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Hatch Date:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(88, 117)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Sex:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(72, 150)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Weight:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(49, 183)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Color Morph:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(27, 216)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(89, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Next Breed Date:"
        '
        'txtSpecimen
        '
        Me.txtSpecimen.Location = New System.Drawing.Point(122, 15)
        Me.txtSpecimen.Name = "txtSpecimen"
        Me.txtSpecimen.Size = New System.Drawing.Size(100, 20)
        Me.txtSpecimen.TabIndex = 1
        '
        'txtSpecies
        '
        Me.txtSpecies.Location = New System.Drawing.Point(122, 48)
        Me.txtSpecies.Name = "txtSpecies"
        Me.txtSpecies.ReadOnly = True
        Me.txtSpecies.Size = New System.Drawing.Size(100, 20)
        Me.txtSpecies.TabIndex = 8
        Me.txtSpecies.TabStop = False
        '
        'txtHatchDate
        '
        Me.txtHatchDate.Location = New System.Drawing.Point(122, 81)
        Me.txtHatchDate.Name = "txtHatchDate"
        Me.txtHatchDate.ReadOnly = True
        Me.txtHatchDate.Size = New System.Drawing.Size(100, 20)
        Me.txtHatchDate.TabIndex = 9
        Me.txtHatchDate.TabStop = False
        '
        'txtSex
        '
        Me.txtSex.Location = New System.Drawing.Point(122, 114)
        Me.txtSex.Name = "txtSex"
        Me.txtSex.ReadOnly = True
        Me.txtSex.Size = New System.Drawing.Size(100, 20)
        Me.txtSex.TabIndex = 10
        Me.txtSex.TabStop = False
        '
        'txtWeight
        '
        Me.txtWeight.Location = New System.Drawing.Point(122, 147)
        Me.txtWeight.Name = "txtWeight"
        Me.txtWeight.ReadOnly = True
        Me.txtWeight.Size = New System.Drawing.Size(100, 20)
        Me.txtWeight.TabIndex = 11
        Me.txtWeight.TabStop = False
        '
        'txtColorMorph
        '
        Me.txtColorMorph.Location = New System.Drawing.Point(122, 180)
        Me.txtColorMorph.Name = "txtColorMorph"
        Me.txtColorMorph.ReadOnly = True
        Me.txtColorMorph.Size = New System.Drawing.Size(100, 20)
        Me.txtColorMorph.TabIndex = 12
        Me.txtColorMorph.TabStop = False
        '
        'txtNextBreedDate
        '
        Me.txtNextBreedDate.Location = New System.Drawing.Point(122, 213)
        Me.txtNextBreedDate.Name = "txtNextBreedDate"
        Me.txtNextBreedDate.ReadOnly = True
        Me.txtNextBreedDate.Size = New System.Drawing.Size(100, 20)
        Me.txtNextBreedDate.TabIndex = 13
        Me.txtNextBreedDate.TabStop = False
        '
        'btnBreedingPrediction
        '
        Me.btnBreedingPrediction.Location = New System.Drawing.Point(30, 245)
        Me.btnBreedingPrediction.Name = "btnBreedingPrediction"
        Me.btnBreedingPrediction.Size = New System.Drawing.Size(125, 23)
        Me.btnBreedingPrediction.TabIndex = 14
        Me.btnBreedingPrediction.Text = "&Breeding Prediction"
        Me.btnBreedingPrediction.UseVisualStyleBackColor = True
        '
        'btnMF
        '
        Me.btnMF.Location = New System.Drawing.Point(30, 274)
        Me.btnMF.Name = "btnMF"
        Me.btnMF.Size = New System.Drawing.Size(125, 23)
        Me.btnMF.TabIndex = 15
        Me.btnMF.Text = "&Maintenance/Feeding"
        Me.btnMF.UseVisualStyleBackColor = True
        '
        'btnExport
        '
        Me.btnExport.Location = New System.Drawing.Point(41, 332)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.Size = New System.Drawing.Size(75, 23)
        Me.btnExport.TabIndex = 16
        Me.btnExport.Text = "&Export"
        Me.btnExport.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(147, 332)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 17
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(91, 303)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(75, 23)
        Me.btnSearch.TabIndex = 27
        Me.btnSearch.Text = "&Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'frmViewSpecimenEmployee
        '
        Me.AcceptButton = Me.btnExport
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(243, 367)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnExport)
        Me.Controls.Add(Me.btnMF)
        Me.Controls.Add(Me.btnBreedingPrediction)
        Me.Controls.Add(Me.txtNextBreedDate)
        Me.Controls.Add(Me.txtColorMorph)
        Me.Controls.Add(Me.txtWeight)
        Me.Controls.Add(Me.txtSex)
        Me.Controls.Add(Me.txtHatchDate)
        Me.Controls.Add(Me.txtSpecies)
        Me.Controls.Add(Me.txtSpecimen)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmViewSpecimenEmployee"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "View Specimen"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txtSpecimen As TextBox
    Friend WithEvents txtSpecies As TextBox
    Friend WithEvents txtHatchDate As TextBox
    Friend WithEvents txtSex As TextBox
    Friend WithEvents txtWeight As TextBox
    Friend WithEvents txtColorMorph As TextBox
    Friend WithEvents txtNextBreedDate As TextBox
    Friend WithEvents btnBreedingPrediction As Button
    Friend WithEvents btnMF As Button
    Friend WithEvents btnExport As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnSearch As Button
End Class
