﻿Public Class frmAddSpecimen
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim Owner As New frmOwner
        Owner.Show()
        Me.Hide()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim specimenNumber As String
        Dim species As String
        Dim hatchDate As String
        Dim sex As String
        Dim weight As String
        Dim colorMorph As String
        Dim nextBreedDate As String

        specimenNumber = txtSpecimen.Text.ToString
        species = txtSpecies.Text.ToString
        hatchDate = txtHatchDate.Text.ToString
        sex = txtSex.Text.ToString
        weight = txtWeight.Text.ToString
        colorMorph = txtColorMorph.Text.ToString
        nextBreedDate = txtNextBreedDate.Text.ToString

        Label8.Text = specimenNumber
        Label9.Text = species
        Label10.Text = hatchDate
        Label11.Text = sex
        Label12.Text = weight
        Label13.Text = colorMorph
        Label14.Text = nextBreedDate
    End Sub
End Class